package com.packtpub.onlineauction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineauctionApplicationTests {

	@Test
	void contextLoads() {
	}

}
