package com.packtpub.onlineauction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineauctionApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineauctionApplication.class, args);
	}

}
